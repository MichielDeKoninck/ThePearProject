Year: 2018-2019
Project: pear
Author 1: Taoufik, Benyahia
Author 2: Michiel, De Koninck 
Needed libraries:
* /
Instructions:
* Open file FEM.m : run using argument 'orchard' or 'shelflife'... to test different conditions
Can we use and modify your code for demonstrations concerning the course? Yes