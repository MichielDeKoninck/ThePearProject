Year: 2018-2019

Project: pear

Author 1: Taoufik, Benyahia

Author 2: Michiel, De Koninck


Needed libraries: FORTRAN MINPACK LIBRARY (already included within code because slightly adjusted for our project)


*/
Instructions:
* 

MATLAB:
Open file FEM.m : run using argument 'optimalCA' or 'shelflife'... to test different conditions

FORTRAN: 
Follow instructions in FortranPearREADME. To visualise results, matlab functions are used. 

Can we use and modify your code for demonstrations concerning the course? Yes