%Example code to plot the results of our concentration calculations

u_cu=u(1:613);
u_cv= u(614:1226);
pdeplot(p,e,t);
pdeplot(p,e,t,'XYData',u_cu, 'colormap','jet')
pdeplot(p,e,t,'XYData',u_cv, 'colormap','jet')
plot(u(1:613));