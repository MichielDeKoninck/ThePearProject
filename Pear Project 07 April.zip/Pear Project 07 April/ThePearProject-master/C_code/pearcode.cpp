#include<iostream>

//Declare all global variables which will be required


int main(){
	loaddata();
	calculate(-1,2,0.7,"optimalCA.txt"); //Optimal CA, de laatste van de storage discriptions.
}
