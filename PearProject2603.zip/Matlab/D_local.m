function [ D_adjustment ] = D_local(length_of_boundary,x1,x2)
% D_local adjustment calculation for one mesh triangle
    D_adjustment = length_of_boundary*[(2*x1+x2)/6 ; (x1+2*x2)/6]; %TODO Should this be negative?
    
    if(any(isnan(D_adjustment)))
        disp('NaN-value spotted during local D calculation')
    end
    
end
