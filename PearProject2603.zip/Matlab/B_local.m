function [ B_adjustment ] = B_local( Ak,x1,x2,x3 )
% B_local adjustment calculation for one mesh triangle

    B_adjustment = (Ak/60)*[[6*x1+2*x2+2*x3 2*x1+2*x2+x3   2*x1+x2+2*x3];
                [2*x1+2*x2+x3   2*x1+6*x2+2*x3 x1+2*x2+2*x3];
                [2*x1+x2+2*x3   x1+2*x2+2*x3   2*x1+2*x2+6*x3]];
    
   %TODO: implement way of checking for NaN's
    if(any(any(isnan(B_adjustment))))
        disp('NaN-value spotted during local B calculation')
    end
    
end