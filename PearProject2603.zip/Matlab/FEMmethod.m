%Finite-element method implementation

%% Constanten
%EXAMPLE: ORCHARD CONDITIONS:
T_ref=293.15;
T=25+273.15;
eta_u = 0.208;
eta_v =0.0004;

%DIFFUSIVITIES
sigma_ur= 2.8*10^(-10);
sigma_uz= 1.10*10^(-9);
sigma_vr= 2.32*10^(-9);
sigma_vz= 6.97*10^(-9);

%RESPIRATION KINETIC PARAMETERS
V_mu_ref=2.39*10^(-4);
E_a_vmu_ref = 80200;
V_mfv_ref= 1.61*10^(-4);
E_a_vmfv_ref = 56700;

K_mu=0.4103;
K_mv=27.2438;
K_mfu=0.1149;

r_q=0.97;

rho_u=7*10^(-7);
rho_v=7.5*10^(-7);

p_atm=101300;
R_g= 8.314;

%TO COPY IN CODE:
V_mu=V_mu_ref*exp((E_a_vmu_ref/R_g)*((1/T_ref)-(1/T)));
V_mfv = V_mfv_ref*exp((E_a_vmfv_ref/R_g)*((1/T_ref)-(1/T)));

Cu_amb = p_atm*eta_u/(R_g*T);
Cv_amb = p_atm*eta_v/(R_g*T);

%% Points en indices laden
example = matfile('save_p.mat');
p = example.p;
example = matfile('save_t.mat');
t = example.t;
example = matfile('save_e.mat');
e = example.e;

%%  Creation of empty matrices

M=size(p,2); %number of nodes 
T=size(t,2); %number of triangles
B=size(e,2); %number of edges 

% TODO: spaarse implementatie zal waarschijnlijk voor meer effici�ntie zorgen
%Ku=sparse(M,M); %Onze K matrix, MxM (zal spaars worden ingevuld) 
K_u=(zeros(M,M)); %Niet spaars
K_v=(zeros(M,M)); %Niet spaars

% TODO: matrices voor niet-lineaire toevoeging

%kan bijvoorbeeld de Kv matrix zijn
F_u=zeros(M,1); % load vector Fu to hold integrals of phi's times load f(x,y)
F_v=zeros(M,1); 

%B EN A ALTERNATIEF: 
A_u = zeros(M,M);
A_v = zeros(M,M);
B = zeros(M,M);
C = zeros(M,M);
D = zeros(M,1);



%% Calculations

%Loop over triangles: 
for triangle_index=1:T %integrate over one triangular element at a time
    %TODO: rand check nog hiervoor?
    nodes = t(1:3,triangle_index); %kolomvector met nodes van triangle
    %triangleCoordinatesMatrix = [ones(3,1),p(:,nodes)']; %Een 3x3 matrix bouwen met co�rdinaten relevant voor deze driehoek.
    triangleCoordinatesMatrix = [p(:,nodes)']; 
%     x1 = triangleCoordinatesMatrix(1,2); y1 = triangleCoordinatesMatrix(1,3); 
%     x2 = triangleCoordinatesMatrix(2,2); y2 = triangleCoordinatesMatrix(2,3); 
%     x3 = triangleCoordinatesMatrix(3,2); y3 = triangleCoordinatesMatrix(3,3);
    x1 = triangleCoordinatesMatrix(1,1); y1 = triangleCoordinatesMatrix(1,2); 
    x2 = triangleCoordinatesMatrix(2,1); y2 = triangleCoordinatesMatrix(2,2); 
    x3 = triangleCoordinatesMatrix(3,1); y3 = triangleCoordinatesMatrix(3,2);
    
    % opp = (1/2)*abs(x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2)); %Alternatief voor oppervlakte
    %Ak = abs(det(triangleCoordinatesMatrix))/2; %Calculation of Area
    Ak = abs(x1*(y2-y3) + x2*(y3-y1) + x3*(y1-y2))/2;
      
    %check: moet dit nodes' zijn?
%     K_u(nodes,nodes)= K_u(nodes,nodes) + K_adjustment(Ak,triangleCoordinatesMatrix,sigma_ur,sigma_uz); %neemt automatisch juiste combinaties
%     K_v(nodes,nodes)= K_u(nodes,nodes) + K_adjustment(Ak,triangleCoordinatesMatrix,sigma_vr,sigma_vz);
    
    A_u(nodes,nodes)= A_u(nodes,nodes) + A_local(Ak,x1,y1,x2,y2,x3,y3,sigma_ur,sigma_uz); %neemt automatisch juiste combinaties
    A_v(nodes,nodes)= A_v(nodes,nodes) + A_local(Ak,x1,y1,x2,y2,x3,y3,sigma_vr,sigma_vz);
    %ALTERNATIEF MET B en A AANPASSINGEN, ONDERAANVOEREN VAN TAOUFIK
    %BENYAHIA*
    
    %I_u = diag([sigma_ur sigma_uz]); %vermenigvuldiging moet al binnenin
    %A_local function om dimensies te doen kloppen.
    %I_v = diag([sigma_vr sigma_vz]);
    
    %A_u(nodes,nodes) = A_u(nodes,nodes) + (A_local(Ak,x1,y1,x2,y2,x3,y3,sigma_ur,sigma_uz));
    %A_v(nodes,nodes) = A_v(nodes,nodes) + (A_local(Ak,x1,y1,x2,y2,x3,y3,sigma_vr,sigma_vz));

    B(nodes,nodes) = B(nodes,nodes) + B_local(Ak,x1,x2,x3);
    
    
    
end %internal triangles have been handled

%Loop over boundaries (only gamma2!):
for edge_index=1:B
    nodes = e(1:2,edge_index);
    x1 = p(1,nodes(1)); y1 = p(2,nodes(1)); %Co�rdinaten ophalen
    x2 = p(1,nodes(2)); y2 = p(2,nodes(2));
    length_of_boundary = sqrt((x2-x1)^2+(y2-y1)^2);
   
    C(nodes,nodes)= C(nodes,nodes) + C_local(length_of_boundary,x1,x2); 
    D(nodes)= D(nodes) + D_local(length_of_boundary,x1,x2);
end

% %Loop over boundaries (only gamma2!):
% for edge_index=1:B
%     nodes = e(1:2,edge_index);
%     x1 = p(1,nodes(1)); y1 = p(2,nodes(1)); %Co�rdinaten ophalen
%     x2 = p(1,nodes(2)); y2 = p(2,nodes(2));
%     length_edge = sqrt((x2-x1)^2 + (y2-y1)^2);
%    %TODO: if (x1 > 0.0017 && x2 > 0.0017) %Dan zitten we niet met een gamma1 edge
%    %Adjustments to K:
%    K_u(nodes,nodes) = K_u(nodes,nodes) + K_edge_adjustment(x1,y1,x2,y2,rho_u);
%    K_v(nodes,nodes) = K_v(nodes,nodes) + K_edge_adjustment(x1,y1,x2,y2,rho_v);
%    
% 
%    %Adjustments to F: 
%    F_u(nodes,1) = F_u(nodes,1) + F_edge_adjustment(x1,y1,x2,y2,rho_u,Cu_amb);
%    F_v(nodes,1) = F_v(nodes,1) + F_edge_adjustment(x1,y1,x2,y2,rho_v,Cv_amb);
% end


%Niet lineair stuk: Berekening u0 en v0 via linearisatie

%De Jacobiaan en F defini�ren zodat we newton rhapson kunnen doorvoeren
%F is gewoon de gehele uitdrukking en J is de partiele afgeleide ervan (u
%deel naar u en v); v deel naar u en v. 

%F = @(c_u,c_v) [Ku*c_u + %TODO; waar lezen we deze vgl mooi af? 
    

%R_v(c_u,c_v, r_q, V_mfv,K_mfu,V_mu,K_mu,K_mv)
%dRudcu( c_u,c_v,V_mu,K_mu,K_mv )
%dRudcv( c_u,c_v,V_mu,K_mu,K_mv )
%dRvdcv(c_u,c_v,r_q,V_mu,K_mu,K_mv )
%dRvdcu( c_u,c_v,r_q,V_mu,K_mu,K_mv,V_mfu,K_mfu )

F = @(c_u,c_v) [A_u*c_u+B*R_u(c_u,c_v, V_mu,K_mu,K_mv)+rho_u*(C*c_u-D*Cu_amb);
                    A_v*c_v-B*R_v(c_u,c_v, r_q, V_mfv,K_mfu,V_mu,K_mu,K_mv)+rho_v*(C*c_v-D*Cv_amb)];
J = @(c_u,c_v) [[A_u'+B*dRudcu( c_u,c_v,V_mu,K_mu,K_mv )+rho_u*C' B*dRudcv( c_u,c_v,K_mu,K_mv )];
        [-B*dRvdcu( c_u,c_v,r_q,V_mu,K_mu,K_mv,V_mfv,K_mfu ) A_v'-B*dRvdcv(c_u,c_v,r_q,V_mu,K_mu,K_mv)+rho_v*C']];

c_u0 = (A_u+(V_mu/K_mu)*B+rho_u*C)\(rho_u*D*Cu_amb);
c_v0 = (A_v+rho_v*C)\(r_q*(V_mu/K_mu)*B*c_u0+rho_v*D*Cv_amb);

[c_u,c_v] = NewtonRaphson( F,J,c_u0,c_v0,5*10^(-11));



%% Repetition 

%Newton-Raphson gebruiken tot convergentie:







