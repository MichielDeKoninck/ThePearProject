function [ C_adjustment ] = C_local(length_of_boundary,x1,x2)
% C_local adjustment calculation for one mesh triangle
    C_adjustment = length_of_boundary*[[(3*x1+x2)/12 (x1+x2)/12];[(x1+x2)/12 (x1+3*x2)/12]];
    
    if(any(any(isnan(C_adjustment))))
        disp('NaN-value spotted during local C calculation')
    end

end