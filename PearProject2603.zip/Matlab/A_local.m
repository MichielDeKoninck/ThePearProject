function [ A_adjustment ] = A_local( Ak,x1,y1,x2,y2,x3,y3,sigma_r,sigma_z)
% A_local adjustment calculation for one mesh triangle

    H = [[(y2-y3) (x3-x2)];
        [(y3-y1) (x1-x3)];
        [(y1-y2) (x2-x1)]];
    
    I = diag([sigma_r sigma_z]);
    
    A_adjustment= (1/(2*Ak))*(x1/6 +x2/6+ x3/6)*(H*I*H');

    if(any(any(isnan(A_adjustment))))
        disp('NaN during local A calculation')
    end

end